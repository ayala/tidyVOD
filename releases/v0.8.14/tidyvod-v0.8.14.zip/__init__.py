"""Dispatcharr tidyVOD plugin package."""
